package function1;

public class Function1 {
    // Method untuk menjumlahkan dua bilangan bulat
    public int add(int a, int b) {
        // Langsung mengembalikan hasil penjumlahannya
        return a + b;
    }

    // Method untuk mengalikan dua bilangan bulat
    public int multiply(int a, int b) {
        // Langsung mengembalikan hasil perkaliannya
        return a * b;
    }
}
