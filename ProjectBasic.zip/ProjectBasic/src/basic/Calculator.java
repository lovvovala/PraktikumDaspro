package basic;

public class Calculator {
    public int add(int number1, int number2) {
        int hasil = 0;
        hasil = number1 + number2;
        return hasil;

    }
}
